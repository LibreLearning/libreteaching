#!/usr/bin/Rscript 
library(RSQLite)

#Modify the following value to the actual path of the DB
#dbpath = "fm3_evince_svn_scm.db"

args <- commandArgs(trailingOnly = TRUE)
dbpath=args[1]

drv = dbDriver("SQLite")

con = dbConnect(drv, dbpath)

rs= dbGetQuery(con, "SELECT f.id, COUNT(a.id) numactions
FROM scmlog s, actions a, files f
WHERE s.id=a.commit_id AND a.file_id=f.id
GROUP BY f.id")

postscript("tot-num-actions-per-file.pdf", horizontal=T)
plot(rs[,1],rs[,2], type="l", main="Tot. num. actions per file", xlab="File", ylab="Num. actions")
dev.off()

sink("tot-num-actions-per-file.txt")
rs
sink()

dbDisconnect(con)


 
