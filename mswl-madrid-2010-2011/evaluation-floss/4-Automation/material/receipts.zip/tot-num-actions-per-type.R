#!/usr/bin/Rscript 
library(RSQLite)

#Modify the following value to the actual path of the DB
#dbpath = "fm3_evince_svn_scm.db"

args <- commandArgs(trailingOnly = TRUE)
dbpath=args[1]

drv = dbDriver("SQLite")

con = dbConnect(drv, dbpath)

rs= dbGetQuery(con, "SELECT type, COUNT(a.id)
FROM actions a GROUP BY type")

postscript("tot-num-actions-per-type.pdf", horizontal=T)
barplot(rs[,2],names=rs[,1], xlab="Action type", ylab="Num. actions", main="Total num. actions per type")
dev.off()

sink("tot-num-actions-per-type.txt")
rs
sink()

dbDisconnect(con)


 
