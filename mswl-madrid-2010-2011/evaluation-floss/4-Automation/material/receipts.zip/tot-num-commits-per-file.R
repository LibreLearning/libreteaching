#!/usr/bin/Rscript 
library(RSQLite)

#Modify the following value to the actual path of the DB
#dbpath = "fm3_evince_svn_scm.db"

args <- commandArgs(trailingOnly = TRUE)
dbpath=args[1]

drv = dbDriver("SQLite")

con = dbConnect(drv, dbpath)

rs= dbGetQuery(con, "SELECT f.id, COUNT(s.id)
FROM scmlog s, actions a, file_types f
WHERE s.id=a.commit_id
AND a.file_id=f.id
GROUP BY f.id")

postscript("tot-num-commits-per-file.pdf", horizontal=T)
plot(rs[,1],rs[,2], type="l", main="Tot. num. commits per file", xlab="File", ylab="Num. commits")
dev.off()

sink("tot-num-commits-per-file.txt")
rs
sink()

dbDisconnect(con)


 
