#!/usr/bin/Rscript 
library(RSQLite)

#Modify the following value to the actual path of the DB
#dbpath = "fm3_evince_svn_scm.db"

args <- commandArgs(trailingOnly = TRUE)
dbpath=args[1]

drv = dbDriver("SQLite")

con = dbConnect(drv, dbpath)

rs= dbGetQuery(con, "SELECT a.type, COUNT(distinct a.file_id) numfiles
FROM actions a GROUP BY a.type")

postscript("tot-num-files-per-action-type.pdf", horizontal=T)
barplot(rs[,2],names=rs[,1], main="Tot. num. of actions per type", xlab="Action type", ylab="Num. files")
dev.off()

sink("tot-num-files-per-action-type.txt")
rs
sink()

dbDisconnect(con)

