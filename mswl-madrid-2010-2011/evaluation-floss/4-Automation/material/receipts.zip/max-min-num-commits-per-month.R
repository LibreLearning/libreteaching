#!/usr/bin/Rscript 
library(RSQLite)

#Modify the following value to the actual path of the DB
#dbpath = "fm3_evince_svn_scm.db"

args <- commandArgs(trailingOnly = TRUE)
dbpath=args[1]

drv = dbDriver("SQLite")

con = dbConnect(drv, dbpath)

rs= dbGetQuery(con, "SELECT MAX(g.numcommits), MIN(g.numcommits)
FROM ( SELECT strftime('%Y', s.date) myyear, strftime('%m', s.date) mymonth, count(s.id) numcommits
FROM scmlog s
GROUP BY strftime('%Y%m',s.date) ) g")

sink("max-min-num-commits-per-month.txt")
rs
sink()

dbDisconnect(con)


 
