#!/usr/bin/Rscript 
library(RSQLite)

#Modify the following value to the actual path of the DB
#dbpath = "fm3_evince_svn_scm.db"

args <- commandArgs(trailingOnly = TRUE)
dbpath=args[1]

drv = dbDriver("SQLite")

con = dbConnect(drv, dbpath)

rs= dbGetQuery(con, "SELECT strftime('%Y',s.date) myyear, strftime('%m',s.date) mymonth, COUNT(distinct (a.file_id)) count
FROM scmlog s, actions a
WHERE s.id=a.commit_id
GROUP BY strftime('%Y%m', s.date)")

#Transform date string into integers
rs[,1]=as.integer(rs[,1])
rs[,2]=as.integer(rs[,2])

#Define function to fill in values for missing dates in time series
fill_gaps <- function(x) {
   DF <- data.frame(myyear = x$myyear[1], mymonth = 1:max(x$mymonth), count = 0)
   DF[x$mymonth,"count"] <- x$count
   DF
}

#Fill in the gaps
rs=do.call(rbind, by(rs, cumsum(rs$mymonth == 1), fill_gaps)) 

#Create ts object
rs_ts = ts (rs[,3], start=c(rs[1,1],rs[1,2]), frequency=12)

postscript("num-files-per-month.pdf",horizontal=T)
plot(rs_ts, main="Number of files per month", ylab="Number of files")
dev.off()

sink("num-files-per-month.txt")
rs
sink()

dbDisconnect(con)


 
