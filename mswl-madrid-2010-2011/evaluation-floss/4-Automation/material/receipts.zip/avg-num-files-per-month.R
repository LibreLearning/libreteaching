#!/usr/bin/Rscript 
library(RSQLite)

#Modify the following value to the actual path of the DB
#dbpath = "fm3_evince_svn_scm.db"

args <- commandArgs(trailingOnly = TRUE)
dbpath=args[1]

drv = dbDriver("SQLite")

con = dbConnect(drv, dbpath)

rs= dbGetQuery(con, "SELECT AVG(g.numfiles)
FROM (SELECT strftime('%Y',s.date) myyear, strftime('%m',s.date) mymonth, COUNT(distinct a.file_id) numfiles
FROM scmlog s, actions a
WHERE s.id=a.commit_id
AND a.file_id NOT IN
(SELECT distinct file_id FROM actions WHERE type='D' )
GROUP BY strftime('%Y%m',s.date)) g")

sink("avg-num-files-per-month.txt")
rs
sink()

dbDisconnect(con)


 
