#!/usr/bin/Rscript 
library(RSQLite)

#Modify the following value to the actual path of the DB
#dbpath = "fm3_evince_cvsanaly2_svn_scm.db"

args <- commandArgs(trailingOnly = TRUE)
dbpath=args[1]

drv = dbDriver("SQLite")

con = dbConnect(drv, dbpath)

rs= dbGetQuery(con, "SELECT strftime('%Y',s.date) myyear, strftime('%m',s.date) mymonth, count(s.id) count
FROM scmlog s group by strftime('%Y%m',s.date)")

#Transform date string into integers
rs[,1]=as.integer(rs[,1])
rs[,2]=as.integer(rs[,2])

years=min(rs$myyear):max(rs$myyear)

first=T
rs_final=data.frame()
for (ayear in years) {
  rs_loop=rs[rs$myyear==ayear,]
  #Fill in the gaps
  if (first) {
    DF = data.frame(myyear = ayear, mymonth = min(rs_loop$mymonth):max(rs_loop$mymonth), count = 0)
    DF[DF$mymonth==rs_loop$mymonth,"count"] <- rs_loop$count
    rs_final=DF
  }
  else {
    DF = data.frame(myyear = ayear, mymonth = 1:max(rs_loop$mymonth), count = 0)
    DF[rs_loop$mymonth,"count"] <- rs_loop$count
    rs_final=rbind(rs_final,DF)
  }
  first=F
}

#Create ts object
rs_ts = ts (rs_final[,3], start=c(rs_final[1,1],rs_final[1,2]), frequency=12)

#Print results
postscript("num-commits-per-month.pdf",horizontal=T)
plot(rs_ts, main="Number of commits per month", ylab="Number of commits")
dev.off()

postscript("num-commits-per-month-stl.pdf",horizontal=T)
plot(stl(rs_ts, s.window="periodic"), main="Decomposition of num. commits per month")
dev.off()

sink("num-commits-per-month.txt")
rs
sink()

dbDisconnect(con)

 

 
