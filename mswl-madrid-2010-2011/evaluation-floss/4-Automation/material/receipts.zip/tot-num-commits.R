#!/usr/bin/Rscript 
library(RSQLite)

#Modify the following value to the actual path of the DB
#dbpath = "fm3_evince_svn_scm.db"

args <- commandArgs(trailingOnly = TRUE)
dbpath=args[1]

drv = dbDriver("SQLite")

con = dbConnect(drv, dbpath)

rs= dbGetQuery(con, "SELECT count(id) FROM scmlog")

sink("tot-num-commits.txt")
print(paste("Total number of commits = ", rs[1,1]))
sink()

dbDisconnect(con)


 
