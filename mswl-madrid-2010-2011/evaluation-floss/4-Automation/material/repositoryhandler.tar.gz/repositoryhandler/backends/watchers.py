N_WATCHES = 7

(
    CHECKOUT,
    UPDATE,
    LOG,
    DIFF,
    BLAME,
    CAT,
    LS
) = range (N_WATCHES)
